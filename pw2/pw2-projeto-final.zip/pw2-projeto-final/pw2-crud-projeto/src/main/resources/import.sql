#INSERT INTO Usuario(id, login, password, email, admin) VALUES (nextval('hibernate_sequence'),'admin','1234', 'admin@email.com', true);

