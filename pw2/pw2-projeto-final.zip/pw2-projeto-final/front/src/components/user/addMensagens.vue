<template>
<h2>Add Mensagem </h2>
     <button @click="voltar" class="waves-effect waves-light btn-small">Voltar<i class="material-icons left">arrow_back</i></button>
    


</template>
<script>

export default {
    name: 'AddMensagens',

    data() {
        
    },
}
</script>
<style scoped>

</style>