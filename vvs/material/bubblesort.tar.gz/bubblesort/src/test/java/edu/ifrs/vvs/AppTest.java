/**
 * @License
 * Copyright 2020 Bubble Sort Application
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package edu.ifrs.vvs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;

/**
 * Unit test for simple App.
 */
class AppTest {
    /**
     * Rigorous Test.
     */

    
    @Test
    @DisplayName("test 1 elemento")
    @Order(1)
    void testApp1() {
        BubbleSort buuble = new BubbleSort();
        int v[] = {2, 1};
        int v2[] = {1, 2};
        buuble.show(v);
        System.out.println();
        buuble.sort(v);
        buuble.show(v);
        System.out.println();
        System.out.println("DEPOIS" + v.toString());
        assertArrayEquals(v, v2);
        
        
    }

    @Test
    @DisplayName("test 2 elementos")
    @Order(2)
    void testApp2Elements() {
        int v[] = {1, 2};
        assertArrayEquals(v, v);
    }

    @Test
    @DisplayName("test 2 elementos invertidos")
    @Order(3)
    void testApp2ElementsInvertidos() {
        int v2[] = {2, 1};
        assertEquals(v2, v2);
    }
}
