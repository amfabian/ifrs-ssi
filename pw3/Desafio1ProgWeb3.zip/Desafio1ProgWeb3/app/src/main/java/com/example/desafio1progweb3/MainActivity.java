package com.example.desafio1progweb3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener {

    private ListView listaViagens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaViagens = findViewById(R.id.listaViagens);
        listaViagens.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
        if (position == 0) {//Travel Activity
            Intent intent = new Intent(this, TravelNyActivity.class);
            startActivity(intent);
        }
        if (position == 1) {
            Intent intent = new Intent(this, TravelSpActivity.class);
            startActivity(intent);
        }
        if (position == 2) {
            Intent intent = new Intent(this, TravelNyActivity.class);
            startActivity(intent);
        }
    }
}